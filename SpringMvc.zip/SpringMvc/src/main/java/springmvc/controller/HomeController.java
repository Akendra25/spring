package springmvc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class HomeController {
	
	
	public String home() {
		System.out.println("This is my url");
		return "index";
		
	}

}
